export const content = {
  name: "Shashank R P",
  title: "Full-stack engineer, problem solver, and tech enthusiast.",
  description: "I love building scalable apps and turning ideas into user-friendly products. Currently at Ellucian, always learning and collaborating.",
  resumeLink: "https://drive.google.com/file/d/1gzb3m_BdrhNwRfRFuF7IblGXIHCnRZip/view?usp=sharing",
  profileImage: "https://shashankrp.in/_next/static/media/shashank.033c1cb8.jpg",
  skills: [
    { name: "React JS", icon: "⚛️" },
    { name: "Tailwind CSS", icon: "🎨" },
    { name: "Java and Spring Boot", icon: "☕︎" },
    { name: "AWS Services", icon: "☁️" },
    { name: "Shell Scripting", icon: "🐚" },
    { name: "Burp Suite and Bruno", icon: "🛠️" }
  ],
  experience: [
    {
      company: "Ellucian Higher Education System",
      location: "Bangalore",
      role: "Software Engineer 1",
      period: "Nov 2022 - Present",
      duration: "3.5 Years",
      points: [
        "Engineered and maintained RESTful APIs using Spring Boot and Java, reducing recurring integration issues by approximately 30% through root-cause analysis and targeted fixes.",
        "Designed and implemented mock API frameworks to decouple testing from upstream dependencies, cutting integration test cycle time by ~40% and enabling parallel development across teams.",
        "Prototyped AWS-based cloud deployment pipelines (EC2, S3) to improve deployment speed and cloud readiness for production releases.",
        "Introduced AI-assisted development workflows (GitHub Copilot, LLM tooling) that increased individual engineering throughput by an estimated 25%.",
        "Collaborated cross-functionally with product, QA, and business teams to define API contracts, write technical documentation, and accelerate partner onboarding.",
        "Implemented comprehensive unit and integration test suites using JUnit and Mockito, improving code coverage and reducing post-release defect rates.",
        "Streamlined development and release processes by introducing standardized branching strategies and code review practices using Git."
      ]
    },
    {
      company: "Voicera Analytics Pvt Ltd",
      location: "Bangalore",
      role: "Software Engineer 1",
      period: "July 2021 - Nov 2022",
      duration: "1.5 Years",
      points: [
        "Built backend services for a Voice Outbound Dialer application using Spring MVC and Java, handling call orchestration, workflow routing, and telephony event processing.",
        "Developed and deployed RESTful APIs consumed by multiple client-facing web applications built with ReactJS and Node.js, enabling seamless frontend-backend integration.",
        "Implemented JWT-based authentication, role-based access control (RBAC), and session management across multiple web applications, improving security posture.",
        "Leveraged AWS Lambda for serverless business logic components, reducing infrastructure overhead and improving scalability for event-driven workflows.",
        "Managed EC2 instance provisioning, configuration, and maintenance for application hosting; used S3 for static asset storage and environment backups.",
        "Delivered 3+ full-stack client projects end-to-end — from requirement gathering to production deployment — with consistent on-time delivery."
      ]
    }
  ],
  blogs: [
    {
      title: "How To Keep AI from Making Us Stupid?",
      excerpt: "AI has become central to much of what we do, but we rely on it more, we are bleeding related skills.",
      content: "AI can be a powerful tool for learning and productivity, but it's essential to use it mindfully..."
    },
    {
      title: "Ghibli-style images",
      excerpt: "ChatGPT's is one of the most commonly used AI tool in the world and it is used by many people for many purposes.",
      content: "If this technology is used in a good way, it can be very helpful for people. But if it is used in a bad way, it can be very dangerous..."
    },
    {
      title: "GIT Best Practices",
      excerpt: "Git is a version control system that allows developers to track changes in their codebase.",
      content: "There are several best practices that developers should follow when using Git..."
    },
    {
      title: "Whatsapp May soon let you stop others from saving media to there devices",
      excerpt: "WhatsApp is one of the most commonly used messaging app in the world and it is used by many people for many purposes.",
      content: "WhatsApp, the Meta instant messaging platform is working on a new feature that makes chats more privacy feature..."
    }
  ],
  cyberSecurity: {
    description: "I’m passionate about cyber security—protecting data, applications, and users from threats. I regularly explore best practices, vulnerability assessments, and the latest security trends.",
    skills: [
      "Penetration Testing & Vulnerability Assessment",
      "Secure Coding Practices",
      "Network Security & Firewalls",
      "Cloud Security (AWS)",
      "Incident Response & Threat Analysis",
      "Security Automation & Tools (OWASP, Burp Suite, etc.)"
    ],
    moreLink: "https://shashankrp.github.io/"
  },
  about: {
    title: "Hi, I'm Shashank RP 👋",
    description: "I'm a full-stack software engineer with 4+ years of experience, currently building scalable apps at Ellucian. I love turning ideas into reliable, user-friendly products.",
    whatIDo: "I work across the stack—React, Node.js, Python, Java, AWS, and more. Whether it’s crafting interactive UIs or building robust backends, I enjoy solving real-world problems with clean, maintainable code.",
    approach: "I believe in continuous learning and teamwork. I stay up-to-date with new tech, love collaborating, and always aim to deliver solutions that make a difference."
  },
  contact: {
    email: "shashankrp2@gmail.com",
    linkedin: "https://www.linkedin.com/in/shashank-r-p-5a866b15a/",
    github: "https://github.com/shashankrp"
  }
};
