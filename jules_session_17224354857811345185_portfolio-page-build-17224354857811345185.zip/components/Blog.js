"use client";
import React from 'react';
import { Box, Typography, Container, Card, CardContent, Grid } from '@mui/material';
import { content } from '@/data/content';

export default function Blog() {
  return (
    <Box id="blog" sx={{ py: 8 }}>
      <Container maxWidth="lg">
        <Typography variant="h4" component="h2" sx={{ fontWeight: 'bold', mb: 4, display: 'flex', alignItems: 'center', gap: 1 }}>
          📝 Blog Write-ups
        </Typography>
        <Grid container spacing={3}>
          {content.blogs.map((blog, index) => (
            <Grid size={{ xs: 12, md: 6 }} key={index}>
              <Card elevation={0} sx={{ height: '100%', border: '1px solid #e5e7eb', borderRadius: 3, '&:hover': { boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' } }}>
                <CardContent sx={{ p: 3 }}>
                  <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold' }}>
                    {blog.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {blog.excerpt}
                  </Typography>
                  <Typography variant="body1" sx={{ fontSize: '0.9rem' }}>
                    {blog.content}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
}
